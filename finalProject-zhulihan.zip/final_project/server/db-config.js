module.exports = {
  host: "cis550-proj.cwbivagne6aq.us-east-1.rds.amazonaws.com",
  port: "3306",
  user: "wenyax",
  password: "rootroot",
  database: "project",
};
