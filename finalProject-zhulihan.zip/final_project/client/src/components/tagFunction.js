// import { fetchIngredient } from "./getData";
// function getTag(option, index) {
//     fetchIngredient(option.title).then((res) => {return <Chip variant="outlined" label={res.toString()} {...getTagProps({ index })} />;});
// }
// export { getTag };